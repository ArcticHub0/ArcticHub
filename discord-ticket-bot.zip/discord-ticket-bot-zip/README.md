# Discord Ticket Bot

A self-hosted, multi-guild Discord ticket bot built with discord.js v14 and PostgreSQL.

---

## Architecture

### Design philosophy

**Simple first, scalable by design.**  
Everything is driven by database state so the bot survives restarts with zero manual recovery. Each Discord server (guild) is a completely isolated unit in the database — no shared mutable state between guilds.

### Component map

```
src/
├── index.js                ← Startup: DB init → event registration → Discord login
├── deploy-commands.js      ← One-shot CLI to register slash commands with Discord
│
├── db/
│   ├── pool.js             ← pg Pool singleton + schema init (runs schema.sql)
│   ├── guilds.js           ← Guild registration, settings read/write, ticket counter
│   └── tickets.js          ← Panel and ticket CRUD
│
├── commands/
│   ├── setup.js            ← /setup  — configure the bot for a guild
│   └── panel.js            ← /panel  — post a ticket panel embed+button
│
├── handlers/
│   ├── commands.js         ← Command registry + dispatcher
│   └── buttons.js          ← Button handler: ticket:open, ticket:close
│
├── events/
│   └── index.js            ← GuildCreate, GuildDelete, InteractionCreate
│
└── utils/
    ├── embeds.js           ← Shared EmbedBuilder + ActionRowBuilder helpers
    ├── permissions.js      ← isAdmin(), isSupport() — all roles read from DB
    └── transcript.js       ← Fetch and format channel messages as plain text
```

### Database schema (PostgreSQL 16)

```
guilds              — one row per Discord server
guild_settings      — per-guild config (roles, category, log channel, ticket counter)
panels              — posted panel messages (so button clicks can be identified)
tickets             — one row per ticket channel, with transcript on close
```

**Key design decisions:**
- `guild_id` is a `TEXT` primary key (Discord snowflakes fit fine, no bigint needed)
- `ticket_counter` is updated with `UPDATE … RETURNING` in a single atomic query — no race conditions, no sequence gaps per guild
- All role/channel IDs are stored as `TEXT` — Discord IDs are stored as strings everywhere to avoid JS bigint issues
- Tickets store a plain-text transcript on close — upgrade to HTML later without changing the column

### Lifecycle of a ticket

```
User clicks "Open Ticket" button
  → handleButton (ticket:open)
  → getSettings(guildId)             — load config from DB
  → getOpenTicketByUser(...)         — enforce one-ticket-per-user
  → nextTicketNumber(guildId)        — atomic increment in guild_settings
  → guild.channels.create(...)       — create private channel with overwrites
  → createTicket(...)                — persist to tickets table
  → send welcome embed + Close button

User (or support) clicks "Close Ticket"
  → handleButton (ticket:close)
  → getTicketByChannel(channelId)    — load ticket from DB
  → permission check (owner or support role)
  → buildTranscript(channel)         — fetch messages, format as text
  → closeTicket(...)                 — update DB: status, closed_at, transcript
  → post transcript to log_channel
  → delete channel after 5s
```

### Scaling path to 1,000 servers

You won't need to change the architecture. When you're ready:

1. **Sharding**: Replace `new Client(…)` with `new ShardingManager('src/index.js', …)`.  
   The DB layer is already shard-safe — no in-memory guild state is shared.

2. **Connection pooling**: Increase `pool.max` in `src/db/pool.js` from 10 to ~20–50  
   and put PgBouncer in front of PostgreSQL.

3. **Read replicas**: `getSettings` and `getTicketByChannel` are read-only queries.  
   Route them to a replica by passing a second pool.

4. **Transcript storage**: Move `transcript TEXT` to S3/R2 and store a URL instead.  
   Single column change in the schema.

---

## First-time setup

### Prerequisites

- Docker + Docker Compose
- A Discord Application with a bot token ([Discord Developer Portal](https://discord.com/developers/applications))
- Bot invited to your server with scopes: `bot`, `applications.commands`  
  Required permissions: `Manage Channels`, `Send Messages`, `Read Message History`, `View Channels`

### Steps

```bash
# 1. Clone / copy the project
cd discord-ticket-bot

# 2. Create your .env
cp .env.example .env
# Edit .env — fill in DISCORD_TOKEN, DISCORD_CLIENT_ID, DB_PASSWORD

# 3. Start services (DB starts first, bot waits for health check)
docker compose up -d --build

# 4. Register slash commands
#    Dev: register to a single guild instantly
GUILD_ID=your_guild_id docker compose exec bot node src/deploy-commands.js
#    Production: register globally (up to 1h propagation)
docker compose exec bot node src/deploy-commands.js

# 5. In Discord:
#    /setup admin_role:@Admins support_role:@Support ticket_category:#tickets log_channel:#ticket-logs
#    /panel channel:#support
```

### Commands

| Command | Description |
|---------|-------------|
| `/setup` | View or update bot configuration for this server |
| `/panel` | Post a ticket panel embed in a channel |

### Button interactions

| Button | Who can use it |
|--------|----------------|
| 🎫 Open Ticket | Any member |
| 🔒 Close Ticket | Ticket opener or support/admin role |

---

## Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DISCORD_TOKEN` | ✅ | Bot token from Discord Developer Portal |
| `DISCORD_CLIENT_ID` | ✅ | Application ID from Discord Developer Portal |
| `DB_PASSWORD` | ✅ | PostgreSQL password |
| `DB_HOST` | no | Defaults to `db` (Docker service name) |
| `DB_PORT` | no | Defaults to `5432` |
| `DB_NAME` | no | Defaults to `botdb` |
| `DB_USER` | no | Defaults to `botuser` |
| `GUILD_ID` | no | Set only when running `deploy-commands.js` for instant dev registration |

---

## Operations

```bash
# View logs
docker compose logs -f bot

# Restart bot only (no DB downtime)
docker compose restart bot

# Rebuild after code change
docker compose up -d --build bot

# Connect to PostgreSQL
docker compose exec db psql -U botuser -d botdb

# Useful queries
SELECT guild_id, ticket_counter FROM guild_settings;
SELECT id, ticket_number, opener_id, status, opened_at FROM tickets ORDER BY opened_at DESC LIMIT 20;
```
