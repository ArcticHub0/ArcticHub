-- ============================================================
-- Discord Ticket Bot - PostgreSQL Schema
-- Designed for multi-guild isolation and scale to ~1,000 servers
-- ============================================================

-- Guilds table: one row per Discord server that has used the bot
CREATE TABLE IF NOT EXISTS guilds (
    guild_id        TEXT        PRIMARY KEY,        -- Discord guild snowflake (string)
    guild_name      TEXT        NOT NULL,
    joined_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active       BOOLEAN     NOT NULL DEFAULT TRUE
);

-- Guild settings: all per-guild configuration lives here
-- Kept as columns (not JSON) so queries stay typed and indexable
CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id            TEXT        PRIMARY KEY REFERENCES guilds(guild_id) ON DELETE CASCADE,
    support_role_id     TEXT,                       -- Role that can see/handle tickets
    admin_role_id       TEXT,                       -- Role that can configure the bot
    ticket_category_id  TEXT,                       -- Category channel for ticket channels
    log_channel_id      TEXT,                       -- Channel for ticket logs/transcripts
    ticket_counter      INTEGER     NOT NULL DEFAULT 0, -- Increments per ticket (per guild)
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Panels: a message with a "Open Ticket" button posted in a channel
CREATE TABLE IF NOT EXISTS panels (
    id              SERIAL      PRIMARY KEY,
    guild_id        TEXT        NOT NULL REFERENCES guilds(guild_id) ON DELETE CASCADE,
    channel_id      TEXT        NOT NULL,           -- Channel the panel is posted in
    message_id      TEXT        NOT NULL UNIQUE,    -- The panel message ID
    title           TEXT        NOT NULL DEFAULT 'Support Tickets',
    description     TEXT        NOT NULL DEFAULT 'Click the button below to open a ticket.',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_panels_guild ON panels(guild_id);

-- Tickets: one row per ticket channel
CREATE TABLE IF NOT EXISTS tickets (
    id              SERIAL      PRIMARY KEY,
    guild_id        TEXT        NOT NULL REFERENCES guilds(guild_id) ON DELETE CASCADE,
    ticket_number   INTEGER     NOT NULL,           -- Guild-scoped sequential number
    channel_id      TEXT        NOT NULL UNIQUE,    -- The ticket channel
    opener_id       TEXT        NOT NULL,           -- Discord user ID who opened it
    status          TEXT        NOT NULL DEFAULT 'open'  -- open | closed
                        CHECK (status IN ('open', 'closed')),
    transcript      TEXT,                           -- Plain-text transcript on close
    opened_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    closed_at       TIMESTAMPTZ,
    closed_by       TEXT                            -- Discord user ID who closed it
);

CREATE INDEX IF NOT EXISTS idx_tickets_guild   ON tickets(guild_id);
CREATE INDEX IF NOT EXISTS idx_tickets_channel ON tickets(channel_id);
CREATE INDEX IF NOT EXISTS idx_tickets_opener  ON tickets(opener_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status  ON tickets(guild_id, status);

-- Unique ticket number per guild
CREATE UNIQUE INDEX IF NOT EXISTS idx_tickets_guild_number ON tickets(guild_id, ticket_number);
