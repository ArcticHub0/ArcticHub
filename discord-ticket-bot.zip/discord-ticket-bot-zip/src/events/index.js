// src/events/index.js
// Wire up all Discord gateway events.

import { Events } from 'discord.js';
import { registerGuild, deactivateGuild } from '../db/guilds.js';
import { handleCommand } from '../handlers/commands.js';
import { handleButton } from '../handlers/buttons.js';

export function registerEvents(client) {

  // ── Bot ready ──────────────────────────────────────────────────────────────
  client.once(Events.ClientReady, async (c) => {
    console.log(`[BOT] Logged in as ${c.user.tag}`);
    console.log(`[BOT] Serving ${c.guilds.cache.size} guild(s).`);

    // Register every guild the bot is already in (handles restarts gracefully)
    for (const [, guild] of c.guilds.cache) {
      await registerGuild(guild.id, guild.name).catch((err) => {
        console.error(`[DB] Failed to register guild ${guild.id}:`, err.message);
      });
    }

    console.log('[BOT] All guilds registered. Ready.');
  });

  // ── Joined a new guild ─────────────────────────────────────────────────────
  client.on(Events.GuildCreate, async (guild) => {
    console.log(`[BOT] Joined guild: ${guild.name} (${guild.id})`);
    await registerGuild(guild.id, guild.name).catch((err) => {
      console.error(`[DB] Failed to register guild ${guild.id}:`, err.message);
    });
  });

  // ── Removed from a guild ──────────────────────────────────────────────────
  client.on(Events.GuildDelete, async (guild) => {
    console.log(`[BOT] Removed from guild: ${guild.name} (${guild.id})`);
    await deactivateGuild(guild.id).catch((err) => {
      console.error(`[DB] Failed to deactivate guild ${guild.id}:`, err.message);
    });
  });

  // ── All interactions ───────────────────────────────────────────────────────
  client.on(Events.InteractionCreate, async (interaction) => {
    try {
      if (interaction.isChatInputCommand()) {
        await handleCommand(interaction);
      } else if (interaction.isButton()) {
        await handleButton(interaction);
      }
    } catch (err) {
      console.error('[BOT] Unhandled interaction error:', err);
    }
  });
}
