// src/deploy-commands.js
// Register (or update) slash commands with Discord.
// Run this script manually or during container startup when commands change.
//
// Usage:
//   node src/deploy-commands.js           → registers globally (up to 1h propagation)
//   GUILD_ID=123 node src/deploy-commands.js  → registers to a single guild instantly

import 'dotenv/config';
import { REST, Routes } from 'discord.js';
import { getCommandDefinitions } from './handlers/commands.js';

const token     = process.env.DISCORD_TOKEN;
const clientId  = process.env.DISCORD_CLIENT_ID;
const guildId   = process.env.GUILD_ID; // optional — for instant dev registration

if (!token || !clientId) {
  console.error('Missing DISCORD_TOKEN or DISCORD_CLIENT_ID in environment.');
  process.exit(1);
}

const rest     = new REST({ version: '10' }).setToken(token);
const commands = getCommandDefinitions();

try {
  console.log(`Registering ${commands.length} command(s)…`);

  if (guildId) {
    // Guild-scoped: instant, good for development
    await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
    console.log(`✅ Commands registered to guild ${guildId}.`);
  } else {
    // Global: up to 1 hour to propagate, use in production
    await rest.put(Routes.applicationCommands(clientId), { body: commands });
    console.log('✅ Commands registered globally.');
  }
} catch (err) {
  console.error('Failed to register commands:', err);
  process.exit(1);
}
