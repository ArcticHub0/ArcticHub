// src/handlers/buttons.js
// Handles all button interactions.
// Custom IDs follow the pattern:  ticket:open | ticket:close

import {
  PermissionFlagsBits,
  ChannelType,
  OverwriteType,
} from 'discord.js';

import { getSettings, nextTicketNumber } from '../db/guilds.js';
import {
  createTicket,
  getTicketByChannel,
  getOpenTicketByUser,
  closeTicket,
} from '../db/tickets.js';
import { isSupport } from '../utils/permissions.js';
import { buildTranscript } from '../utils/transcript.js';
import {
  ticketWelcomeEmbed,
  closeTicketRow,
  errorEmbed,
  successEmbed,
  infoEmbed,
} from '../utils/embeds.js';

export async function handleButton(interaction) {
  if (!interaction.isButton()) return;

  const [namespace, action] = interaction.customId.split(':');
  if (namespace !== 'ticket') return;

  if (action === 'open') return handleOpen(interaction);
  if (action === 'close') return handleClose(interaction);
}

// ── Open ──────────────────────────────────────────────────────────────────────

async function handleOpen(interaction) {
  await interaction.deferReply({ ephemeral: true });

  const settings = await getSettings(interaction.guildId);

  if (!settings?.ticket_category_id) {
    return interaction.editReply({
      embeds: [errorEmbed('The bot is not fully configured yet. Ask an admin to run `/setup`.')],
    });
  }

  // One open ticket per user per guild
  const existing = await getOpenTicketByUser(interaction.guildId, interaction.user.id);
  if (existing) {
    return interaction.editReply({
      embeds: [errorEmbed(`You already have an open ticket: <#${existing.channel_id}>`)],
    });
  }

  // Atomically get the next ticket number for this guild
  const ticketNumber = await nextTicketNumber(interaction.guildId);
  const channelName  = `ticket-${String(ticketNumber).padStart(4, '0')}`;

  // Build permission overwrites:
  //  - @everyone: deny VIEW
  //  - ticket opener: allow VIEW + SEND
  //  - support role (if set): allow VIEW + SEND
  //  - bot itself: allow VIEW + SEND + MANAGE_CHANNELS
  const overwrites = [
    {
      id:   interaction.guild.roles.everyone.id,
      deny: [PermissionFlagsBits.ViewChannel],
    },
    {
      id:     interaction.user.id,
      type:   OverwriteType.Member,
      allow:  [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    },
    {
      id:    interaction.client.user.id,
      type:  OverwriteType.Member,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.ReadMessageHistory,
      ],
    },
  ];

  if (settings.support_role_id) {
    overwrites.push({
      id:    settings.support_role_id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }

  // Create the channel inside the configured category
  const ticketChannel = await interaction.guild.channels.create({
    name:   channelName,
    type:   ChannelType.GuildText,
    parent: settings.ticket_category_id,
    permissionOverwrites: overwrites,
    topic:  `Ticket #${String(ticketNumber).padStart(4, '0')} | Opened by ${interaction.user.tag}`,
  });

  // Persist to DB
  await createTicket({
    guildId:      interaction.guildId,
    ticketNumber,
    channelId:    ticketChannel.id,
    openerId:     interaction.user.id,
  });

  // Send the welcome message in the ticket channel
  await ticketChannel.send({
    content: `${interaction.user}`,
    embeds:  [ticketWelcomeEmbed(ticketNumber, interaction.user)],
    components: [closeTicketRow()],
  });

  return interaction.editReply({
    embeds: [successEmbed('Ticket Created', `Your ticket has been opened: ${ticketChannel}`)],
  });
}

// ── Close ─────────────────────────────────────────────────────────────────────

async function handleClose(interaction) {
  await interaction.deferReply();

  const settings = await getSettings(interaction.guildId);
  const ticket   = await getTicketByChannel(interaction.channelId);

  if (!ticket) {
    return interaction.editReply({
      embeds: [errorEmbed('This channel is not a registered ticket.')],
    });
  }

  if (ticket.status === 'closed') {
    return interaction.editReply({
      embeds: [errorEmbed('This ticket is already closed.')],
    });
  }

  // Opener can close their own ticket; support/admin can close any
  const isOwner = ticket.opener_id === interaction.user.id;
  if (!isOwner && !isSupport(interaction.member, settings)) {
    return interaction.editReply({
      embeds: [errorEmbed('Only the ticket opener or support staff can close this ticket.')],
    });
  }

  // Build transcript before we delete the channel
  const transcript = await buildTranscript(interaction.channel);

  // Update DB first (so state is correct even if Discord calls fail)
  const closedTicket = await closeTicket({
    channelId:  interaction.channelId,
    closedBy:   interaction.user.id,
    transcript,
  });

  // Post transcript to log channel if configured
  if (settings?.log_channel_id) {
    const logChannel = interaction.guild.channels.cache.get(settings.log_channel_id);
    if (logChannel) {
      const ticketNum = String(closedTicket.ticket_number).padStart(4, '0');
      const opener    = `<@${closedTicket.opener_id}>`;
      const closer    = interaction.user;

      await logChannel.send({
        embeds: [
          infoEmbed(
            `📋 Ticket #${ticketNum} Closed`,
            [
              `**Opened by:** ${opener}`,
              `**Closed by:** ${closer}`,
              `**Opened at:** <t:${Math.floor(new Date(closedTicket.opened_at).getTime() / 1000)}:F>`,
              `**Closed at:** <t:${Math.floor(Date.now() / 1000)}:F>`,
            ].join('\n')
          ),
        ],
      });

      // Post transcript as a file attachment
      if (transcript) {
        await logChannel.send({
          content: `Transcript for ticket #${ticketNum}:`,
          files: [{
            attachment: Buffer.from(transcript, 'utf8'),
            name: `ticket-${ticketNum}-transcript.txt`,
          }],
        });
      }
    }
  }

  // Acknowledge in channel, then delete after a short delay
  await interaction.editReply({
    embeds: [successEmbed('Ticket Closed', 'This ticket has been closed. The channel will be deleted in 5 seconds.')],
  });

  setTimeout(async () => {
    await interaction.channel.delete('Ticket closed').catch(() => {});
  }, 5_000);
}
