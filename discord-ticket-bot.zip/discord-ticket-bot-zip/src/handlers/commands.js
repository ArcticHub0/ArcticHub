// src/handlers/commands.js
// Loads all command modules and dispatches interactions.

import * as setup from '../commands/setup.js';
import * as panel from '../commands/panel.js';

// Map of command name → module
const commands = new Map([
  [setup.data.name, setup],
  [panel.data.name, panel],
]);

/**
 * Returns an array of SlashCommandBuilder .toJSON() objects for registration.
 */
export function getCommandDefinitions() {
  return [...commands.values()].map((cmd) => cmd.data.toJSON());
}

/**
 * Route an interactionCreate event to the correct command handler.
 */
export async function handleCommand(interaction) {
  if (!interaction.isChatInputCommand()) return;

  const cmd = commands.get(interaction.commandName);
  if (!cmd) return;

  try {
    await cmd.execute(interaction);
  } catch (err) {
    console.error(`[CMD] Error in /${interaction.commandName}:`, err);
    const msg = { content: '❌ An internal error occurred. Please try again.', ephemeral: true };
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(msg).catch(() => {});
    } else {
      await interaction.reply(msg).catch(() => {});
    }
  }
}
