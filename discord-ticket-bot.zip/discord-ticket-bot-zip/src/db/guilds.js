// src/db/guilds.js
// All DB operations related to guild registration and settings.

import { query, withClient } from './pool.js';

// ── Guild registration ────────────────────────────────────────────────────────

/**
 * Upsert a guild row when the bot joins (or on startup scan).
 * Creates a matching guild_settings row so there is always exactly one.
 */
export async function registerGuild(guildId, guildName) {
  return withClient(async (client) => {
    await client.query('BEGIN');
    try {
      await client.query(
        `INSERT INTO guilds (guild_id, guild_name, is_active)
         VALUES ($1, $2, TRUE)
         ON CONFLICT (guild_id)
         DO UPDATE SET guild_name = EXCLUDED.guild_name, is_active = TRUE`,
        [guildId, guildName]
      );
      // Ensure a settings row exists (don't overwrite existing config)
      await client.query(
        `INSERT INTO guild_settings (guild_id)
         VALUES ($1)
         ON CONFLICT (guild_id) DO NOTHING`,
        [guildId]
      );
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    }
  });
}

/**
 * Mark guild as inactive when the bot is removed.
 */
export async function deactivateGuild(guildId) {
  await query(
    `UPDATE guilds SET is_active = FALSE WHERE guild_id = $1`,
    [guildId]
  );
}

// ── Settings reads ────────────────────────────────────────────────────────────

export async function getSettings(guildId) {
  const { rows } = await query(
    `SELECT * FROM guild_settings WHERE guild_id = $1`,
    [guildId]
  );
  return rows[0] ?? null;
}

// ── Settings writes ───────────────────────────────────────────────────────────

export async function setSettings(guildId, {
  supportRoleId,
  adminRoleId,
  ticketCategoryId,
  logChannelId,
}) {
  await query(
    `UPDATE guild_settings
     SET support_role_id    = COALESCE($2, support_role_id),
         admin_role_id      = COALESCE($3, admin_role_id),
         ticket_category_id = COALESCE($4, ticket_category_id),
         log_channel_id     = COALESCE($5, log_channel_id),
         updated_at         = NOW()
     WHERE guild_id = $1`,
    [guildId, supportRoleId, adminRoleId, ticketCategoryId, logChannelId]
  );
}

// ── Ticket counter (atomic increment, guild-scoped) ───────────────────────────

/**
 * Atomically increment and return the guild's ticket counter.
 * This is the guild-local ticket number (ticket-0001, ticket-0002, …).
 */
export async function nextTicketNumber(guildId) {
  const { rows } = await query(
    `UPDATE guild_settings
     SET ticket_counter = ticket_counter + 1
     WHERE guild_id = $1
     RETURNING ticket_counter`,
    [guildId]
  );
  return rows[0]?.ticket_counter ?? null;
}
