// src/db/pool.js
// Single pg Pool exported for the whole app.
// All queries go through this — no per-file connections.

import pg from 'pg';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const { Pool } = pg;

const pool = new Pool({
  host:     process.env.DB_HOST     || 'db',
  port:     parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME     || 'botdb',
  user:     process.env.DB_USER     || 'botuser',
  password: process.env.DB_PASSWORD,
  // Keep a small pool — at 1,000 guilds, traffic is still bursty not sustained.
  // Increase max if you add shards later.
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
});

pool.on('error', (err) => {
  console.error('[DB] Unexpected pool error:', err.message);
});

// Run the schema SQL on startup (idempotent — uses IF NOT EXISTS everywhere)
export async function initDb() {
  const __dirname = path.dirname(fileURLToPath(import.meta.url));
  const schema = fs.readFileSync(
    path.join(__dirname, '../../sql/schema.sql'),
    'utf8'
  );
  const client = await pool.connect();
  try {
    await client.query(schema);
    console.log('[DB] Schema applied successfully.');
  } finally {
    client.release();
  }
}

// Convenience wrappers so callers don't import pool directly
export const query = (text, params) => pool.query(text, params);

export async function withClient(fn) {
  const client = await pool.connect();
  try {
    return await fn(client);
  } finally {
    client.release();
  }
}

export default pool;
