// src/db/tickets.js
// All DB operations for tickets and panels.

import { query } from './pool.js';

// ── Panels ────────────────────────────────────────────────────────────────────

export async function createPanel({ guildId, channelId, messageId, title, description }) {
  const { rows } = await query(
    `INSERT INTO panels (guild_id, channel_id, message_id, title, description)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (message_id) DO UPDATE
       SET title = EXCLUDED.title, description = EXCLUDED.description
     RETURNING *`,
    [guildId, channelId, messageId, title, description]
  );
  return rows[0];
}

export async function getPanelByMessage(messageId) {
  const { rows } = await query(
    `SELECT * FROM panels WHERE message_id = $1`,
    [messageId]
  );
  return rows[0] ?? null;
}

// ── Tickets ───────────────────────────────────────────────────────────────────

export async function createTicket({ guildId, ticketNumber, channelId, openerId }) {
  const { rows } = await query(
    `INSERT INTO tickets (guild_id, ticket_number, channel_id, opener_id, status)
     VALUES ($1, $2, $3, $4, 'open')
     RETURNING *`,
    [guildId, ticketNumber, channelId, openerId]
  );
  return rows[0];
}

export async function getTicketByChannel(channelId) {
  const { rows } = await query(
    `SELECT * FROM tickets WHERE channel_id = $1`,
    [channelId]
  );
  return rows[0] ?? null;
}

export async function getOpenTicketByUser(guildId, openerId) {
  const { rows } = await query(
    `SELECT * FROM tickets
     WHERE guild_id = $1 AND opener_id = $2 AND status = 'open'
     LIMIT 1`,
    [guildId, openerId]
  );
  return rows[0] ?? null;
}

export async function closeTicket({ channelId, closedBy, transcript }) {
  const { rows } = await query(
    `UPDATE tickets
     SET status = 'closed',
         closed_at = NOW(),
         closed_by = $2,
         transcript = $3
     WHERE channel_id = $1
     RETURNING *`,
    [channelId, closedBy, transcript]
  );
  return rows[0] ?? null;
}
