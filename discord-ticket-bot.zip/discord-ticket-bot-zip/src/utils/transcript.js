// src/utils/transcript.js
// Fetches recent messages from a ticket channel and formats a plain-text transcript.
// Kept simple — upgrade to HTML later if needed.

/**
 * Fetch up to `limit` messages from a channel and format them as plain text.
 * Discord API returns messages newest-first, so we reverse for chronological order.
 *
 * @param {import('discord.js').TextChannel} channel
 * @param {number} limit  Max messages to fetch (Discord max per call: 100)
 * @returns {Promise<string>}
 */
export async function buildTranscript(channel, limit = 100) {
  const messages = await channel.messages.fetch({ limit });

  const sorted = [...messages.values()].reverse(); // oldest first

  const lines = sorted.map((msg) => {
    const ts = msg.createdAt.toISOString();
    const author = `${msg.author.tag} (${msg.author.id})`;
    const content = msg.content || '[no text content]';
    const attachments = msg.attachments.size
      ? '\n  Attachments: ' + msg.attachments.map((a) => a.url).join(', ')
      : '';
    return `[${ts}] ${author}: ${content}${attachments}`;
  });

  return lines.join('\n');
}
