// src/utils/permissions.js
// Guild-aware permission helpers. All role IDs come from DB, never hardcoded.

import { PermissionFlagsBits } from 'discord.js';

/**
 * Returns true if the member has the configured admin role OR
 * has the ADMINISTRATOR Discord permission.
 */
export function isAdmin(member, settings) {
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (settings?.admin_role_id && member.roles.cache.has(settings.admin_role_id)) return true;
  return false;
}

/**
 * Returns true if the member can handle tickets:
 * - has admin role, OR
 * - has support role, OR
 * - has MANAGE_CHANNELS permission (good Discord-native fallback)
 */
export function isSupport(member, settings) {
  if (isAdmin(member, settings)) return true;
  if (settings?.support_role_id && member.roles.cache.has(settings.support_role_id)) return true;
  return false;
}
