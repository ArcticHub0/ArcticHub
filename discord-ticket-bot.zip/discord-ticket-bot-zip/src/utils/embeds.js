// src/utils/embeds.js
// Reusable Discord.js builders so every command keeps a consistent look.

import {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from 'discord.js';

export const Colors = {
  primary:  0x5865F2,  // Discord blurple
  success:  0x57F287,
  warning:  0xFEE75C,
  error:    0xED4245,
  info:     0x5865F2,
};

// ── Generic embeds ─────────────────────────────────────────────────────────────

export function successEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(Colors.success)
    .setTitle(`✅ ${title}`)
    .setDescription(description)
    .setTimestamp();
}

export function errorEmbed(description) {
  return new EmbedBuilder()
    .setColor(Colors.error)
    .setTitle('❌ Error')
    .setDescription(description)
    .setTimestamp();
}

export function infoEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(Colors.primary)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
}

// ── Panel embed + button ───────────────────────────────────────────────────────

export function panelEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(Colors.primary)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: 'Click the button below to open a support ticket.' })
    .setTimestamp();
}

export function openTicketRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket:open')
      .setLabel('🎫 Open Ticket')
      .setStyle(ButtonStyle.Primary)
  );
}

// ── Ticket channel embed ───────────────────────────────────────────────────────

export function ticketWelcomeEmbed(ticketNumber, opener) {
  return new EmbedBuilder()
    .setColor(Colors.primary)
    .setTitle(`🎫 Ticket #${String(ticketNumber).padStart(4, '0')}`)
    .setDescription(
      `Hello ${opener}, welcome to your support ticket!\n\n` +
      'Please describe your issue and a staff member will be with you shortly.'
    )
    .setTimestamp();
}

export function closeTicketRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket:close')
      .setLabel('🔒 Close Ticket')
      .setStyle(ButtonStyle.Danger)
  );
}
