// src/index.js
// Entry point. Connects to the DB, applies schema, then logs in to Discord.

import 'dotenv/config';
import { Client, GatewayIntentBits, Partials } from 'discord.js';
import { initDb } from './db/pool.js';
import { registerEvents } from './events/index.js';

const token = process.env.DISCORD_TOKEN;

if (!token) {
  console.error('[BOT] DISCORD_TOKEN is not set. Exiting.');
  process.exit(1);
}

// Intents: we only need Guilds (for guild/channel management) and guild messages
// for transcript building.  No privileged intents required.
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,  // needed for reading messages in transcripts
  ],
  partials: [Partials.Channel],
});

async function main() {
  // 1. Apply DB schema (idempotent)
  console.log('[BOT] Initialising database…');
  await initDb();

  // 2. Register event handlers
  registerEvents(client);

  // 3. Connect to Discord
  console.log('[BOT] Connecting to Discord…');
  await client.login(token);
}

main().catch((err) => {
  console.error('[BOT] Fatal startup error:', err);
  process.exit(1);
});
