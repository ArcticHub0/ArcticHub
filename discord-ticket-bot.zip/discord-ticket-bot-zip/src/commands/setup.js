// src/commands/setup.js
// /setup — configure the bot for this guild.
// Only users with admin role or ADMINISTRATOR permission can run this.

import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { getSettings, setSettings } from '../db/guilds.js';
import { isAdmin } from '../utils/permissions.js';
import { successEmbed, errorEmbed } from '../utils/embeds.js';

export const data = new SlashCommandBuilder()
  .setName('setup')
  .setDescription('Configure the ticket bot for this server.')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addRoleOption((o) =>
    o.setName('admin_role')
      .setDescription('Role that can configure the bot')
      .setRequired(false))
  .addRoleOption((o) =>
    o.setName('support_role')
      .setDescription('Role that can view and handle tickets')
      .setRequired(false))
  .addChannelOption((o) =>
    o.setName('ticket_category')
      .setDescription('Category where ticket channels will be created')
      .addChannelTypes(ChannelType.GuildCategory)
      .setRequired(false))
  .addChannelOption((o) =>
    o.setName('log_channel')
      .setDescription('Channel where ticket transcripts are posted on close')
      .addChannelTypes(ChannelType.GuildText)
      .setRequired(false));

export async function execute(interaction) {
  await interaction.deferReply({ ephemeral: true });

  const settings = await getSettings(interaction.guildId);

  if (!isAdmin(interaction.member, settings)) {
    return interaction.editReply({
      embeds: [errorEmbed('You need the Administrator permission or the configured admin role to run /setup.')],
    });
  }

  const adminRole       = interaction.options.getRole('admin_role');
  const supportRole     = interaction.options.getRole('support_role');
  const ticketCategory  = interaction.options.getChannel('ticket_category');
  const logChannel      = interaction.options.getChannel('log_channel');

  // At least one option must be provided
  if (!adminRole && !supportRole && !ticketCategory && !logChannel) {
    const current = settings ?? {};
    return interaction.editReply({
      embeds: [
        successEmbed('Current Configuration', [
          `**Admin Role:** ${current.admin_role_id ? `<@&${current.admin_role_id}>` : '_not set_'}`,
          `**Support Role:** ${current.support_role_id ? `<@&${current.support_role_id}>` : '_not set_'}`,
          `**Ticket Category:** ${current.ticket_category_id ? `<#${current.ticket_category_id}>` : '_not set_'}`,
          `**Log Channel:** ${current.log_channel_id ? `<#${current.log_channel_id}>` : '_not set_'}`,
          '',
          'Provide one or more options to update the configuration.',
        ].join('\n')),
      ],
    });
  }

  await setSettings(interaction.guildId, {
    adminRoleId:       adminRole?.id,
    supportRoleId:     supportRole?.id,
    ticketCategoryId:  ticketCategory?.id,
    logChannelId:      logChannel?.id,
  });

  const updated = [];
  if (adminRole)      updated.push(`Admin Role → ${adminRole}`);
  if (supportRole)    updated.push(`Support Role → ${supportRole}`);
  if (ticketCategory) updated.push(`Ticket Category → ${ticketCategory}`);
  if (logChannel)     updated.push(`Log Channel → ${logChannel}`);

  return interaction.editReply({
    embeds: [successEmbed('Configuration Saved', updated.join('\n'))],
  });
}
