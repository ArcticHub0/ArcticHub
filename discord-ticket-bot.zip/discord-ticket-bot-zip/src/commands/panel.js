// src/commands/panel.js
// /panel — post a ticket panel (embed + Open Ticket button) in a channel.

import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';
import { getSettings } from '../db/guilds.js';
import { createPanel } from '../db/tickets.js';
import { isAdmin } from '../utils/permissions.js';
import { panelEmbed, openTicketRow, errorEmbed, successEmbed } from '../utils/embeds.js';

export const data = new SlashCommandBuilder()
  .setName('panel')
  .setDescription('Post a ticket panel in a channel.')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addChannelOption((o) =>
    o.setName('channel')
      .setDescription('Channel to post the panel in (defaults to current channel)')
      .addChannelTypes(ChannelType.GuildText)
      .setRequired(false))
  .addStringOption((o) =>
    o.setName('title')
      .setDescription('Panel title')
      .setMaxLength(100)
      .setRequired(false))
  .addStringOption((o) =>
    o.setName('description')
      .setDescription('Panel description')
      .setMaxLength(1000)
      .setRequired(false));

export async function execute(interaction) {
  await interaction.deferReply({ ephemeral: true });

  const settings = await getSettings(interaction.guildId);

  if (!isAdmin(interaction.member, settings)) {
    return interaction.editReply({
      embeds: [errorEmbed('You need the Administrator permission or the configured admin role to run /panel.')],
    });
  }

  if (!settings?.ticket_category_id) {
    return interaction.editReply({
      embeds: [errorEmbed('Please run `/setup` first and set a ticket category.')],
    });
  }

  const targetChannel = interaction.options.getChannel('channel') ?? interaction.channel;
  const title         = interaction.options.getString('title')       ?? 'Support Tickets';
  const description   = interaction.options.getString('description') ?? 'Click the button below to open a ticket with our support team.';

  // Post the panel
  const panelMessage = await targetChannel.send({
    embeds: [panelEmbed(title, description)],
    components: [openTicketRow()],
  });

  // Persist so we can identify button interactions later
  await createPanel({
    guildId:     interaction.guildId,
    channelId:   targetChannel.id,
    messageId:   panelMessage.id,
    title,
    description,
  });

  return interaction.editReply({
    embeds: [successEmbed('Panel Created', `Ticket panel posted in ${targetChannel}.`)],
  });
}
